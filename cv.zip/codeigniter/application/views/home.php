<!doctype html>
<html lang="en">
  <head>
    <title>Me &mdash; Website Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Arbutus+Slab|Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="assets/fonts/icomoon/style.css">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">

    <link rel="stylesheet" href="assets/css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="assets/css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="assets/fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="assets/css/aos.css">

    <link rel="stylesheet" href="assets/css/style.css">
    
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  


  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   
    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container-fluid">
        <div class="row align-items-center justify-content-center">
          
          <div class="">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="#home-section" class="nav-link">Home</a></li>
                <li><a href="#services-section" class="nav-link">Biodata</a></li>
                <li><a href="#about-section" class="nav-link">Tentang Saya</a></li>
                
              </ul>
            </nav>
          </div>


          <div class="text-left">

            <nav class="site-navigation position-relative" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="#clients-section" class="nav-link">Client</a></li>
                <li><a href="#contact-section" class="nav-link">Contact</a></li>
              </ul>
            </nav>


            <div class="d-inline-block d-lg-none" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle float-right"><span class="icon-menu h3"></span></a></div>

          </div>

        </div>
      </div>
      
    </header>


    <div class="site-blocks-cover overlay bg-light" id="home-section">

      <div class="container">
        <div class="row justify-content-center">

          <div class="col-md-12 mt-lg-5 text-left align-self-center text-intro">
            <div class="row">
              <div class="col-lg-6">
                <h1 class="text-black">Ahnaf Tias Fauzan</h1>
                <p class="lead"></p>

              </div>
            </div>
          </div>
            
        </div>
      </div>

      <center><img src="assets/images/mawang.jpg"alt="Image" class="img-face" data-aos="fade"></center>

      
    </div>  

    

    
    <div class="site-section" id="services-section">
      <div class="container">
        <div class="row ">
          <div class="col-12 mb-5 position-relative">
            <h2 class="section-title text-center mb-5">Biodata Saya</h2>
          </div>
          
          <div class="col-md-6 mb-4">
            <div class="service d-flex h-100">
              <div class="service-number mr-4"><span class="icon-style"></span></div>
              <div class="service-about">
                <h3>NAMA</h3>
                <p>Ahnaf Tias Fauzan</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 mb-4">
            <div class="service d-flex h-100">
              <div class="service-number mr-4"><span class="icon-business_center"></span></div>
              <div class="service-about">
                <h3>Alamat</h3>
                <p>JL. Cipedes Tengah No.7a</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 mb-4">
            <div class="service d-flex h-100">
              <div class="service-number mr-4"><span class="icon-desktop_windows"></span></div>
              <div class="service-about">
                <h3>JENIS KELAMIN</h3>
                <p>Laki-Laki</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 mb-4">
            <div class="service d-flex h-100">
              <div class="service-number mr-4"><span class="icon-layers"></span></div>
              <div class="service-about">
                <h3>PENDIDIKAN</h3>
                <p> SDN Sukagalih 1 Bandung </p>
				<p> SMP Muhammadiyah 6 Bandung </p>
				<p> SMK AL FALAH</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="site-section" id="about-section">
      <div class="container">
        <div class="row ">
          <div class="col-12 mb-4 position-relative">
            <h2 class="section-title">TENTANG SAYA</h2>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 mb-4 mb-lg-0">
            <div class="bg-light pt-5">
            <img src="assets/images/mawang2.jpg" alt="Image" class="img-fluid">
            </div>
          </div>
          <div class="col-lg-4 order-2 order-lg-1">
            <p>Nama saya Ahnaf Tias Fauzan .</p>
            <p>Saya Lahir di Bandung,18 September 2001.</p>
          </div>
          <div class="col-lg-4 order-3 order-lg-3">
            <p> No Telepon Saya 085862756530 </p>
            <p><a href="#contact-section" class="btn smoothscroll btn-primary">Contact Me</a></p>
          </div>
          
        </div>
      </div>
    </div>



    <section class="site-section bg-dark">
      <div class="container">
        <div class="row">
          <div class="col-12 mb-5 position-relative">
            <h2 class="section-title text-center mb-5 text-white">testimonials</h2>
          </div>
        </div>
        <div class="owl-carousel slide-one-item">
          <div class="slide">
            <blockquote>
              <p><b>Indonesia</b> tanah air kita</p>
              <p><b><i>Tanah</b></i> teu boga <b><i>Cai</b></i> kudu ngala </p>
              <p><cite>&mdash; keurngora</cite></p>
            </blockquote>
          </div>
          <div class="slide">
            <blockquote>
              <p> Pas aku <b>bener</b> ga ada yang <b>inget</b> </p>
              <p> Giliran aing salah eweuh nu <b>poho</b></p>
              <p><cite>&mdash; keurngora</cite></p>
            </blockquote>
          </div>
          <div class="slide">
            <blockquote>
              <p><b>BERI AKU 10 WANITA</b> </p>
              <p>Maka akan kuguncangkan K.U.A</p>
              <p><cite>&mdash; keurngora </cite></p>
            </blockquote>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section"  id="clients-section">
      <div class="container">
        <div class="row">
          <div class="col-12 mb-5 position-relative">
            <h2 class="section-title text-center">Clients</h2>
          </div>
          <div class="col-6 col-sm-6 col-md-4 col-lg-4 text-center">
            <img src="assets/images/logo_1.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-6 col-sm-6 col-md-4 col-lg-4 text-center">
            <img src="assets/images/logo_2.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-6 col-sm-6 col-md-4 col-lg-4 text-center">
            <img src="assets/images/logo_3.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-6 col-sm-6 col-md-4 col-lg-4 text-center">
            <img src="assets/images/logo_4.jpg" alt="Image" class="img-fluid">
          </div>      

          
          <div class="col-6 col-sm-6 col-md-4 col-lg-4 text-center">
            <img src="assets/images/logo_5.jpg" alt="Image" class="img-fluid">
          </div> 
          <div class="col-6 col-sm-6 col-md-4 col-lg-4 text-center">
            <img src="assets/images/logo_6.jpg" alt="Image" class="img-fluid">
          </div> 
        </div>
      </div>
    </section>

  </div> <!-- .site-wrap -->

  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <script src="assets/js/jquery-ui.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/owl.carousel.min.js"></script>
  <script src="assets/js/jquery.easing.1.3.js"></script>
  <script src="assets/js/aos.js"></script>
  <script src="assets/js/jquery.fancybox.min.js"></script>
  <script src="assets/js/jquery.sticky.js"></script>
  <script src="assets/js/isotope.pkgd.min.js"></script>

  
  <script src="assets/js/main.js"></script>
    
  </body>
</html>